import { useEffect, useState } from "react";
import BookModel from "../../models/BookModel";
import { SpinnerLoading } from "../Utils/SpinnerLoading";
import { Checkout } from "./Checkout";
import { useOktaAuth } from "@okta/okta-react";

export const BookCheckoutPage = () => {

    const {authState} = useOktaAuth();

    const [book, setBook] = useState<BookModel>();
    const [isLoadingBook, setIsLoading] = useState(true);
    const [httpError, setHttpError] = useState(null);

    //add start for loans count
    const [currentLoansCount, setcurrentLoansCount] = useState(0);
    const [isLoadingCurrentLoansCount, setIsLoadingCurrentLoansCount] = useState(true);

    //is book checked out state
    const [isCheckedOut, setIsCheckedOut] = useState(false);
    const [isLoadingBookCheckedOut, setIsLoadingBookCheckedOut] = useState(true);

    //get the bookId from the url i.e. localhost:3000/checkout/1
    //window.location.pathname gets the url
    const bookId = (window.location.pathname).split('/')[2];

    //useEffect is called the first time at the creation of the component & it gets called every time something in the last array changes
    //when checkout function happens we're going to re-initialize the useEffect 
    useEffect(() => {
        const fetchBook = async () => {
            const baseUrl: string = `https://localhost:8443/api/books/${bookId}`;

            //we need to use await becaus its an asynchronous function
            const response = await fetch(baseUrl);

            if(!response.ok) {
                throw new Error('Something went wrong');
            }

            const responseJson = await response.json();

            //create a variable of BookModel object & kpublish it with the response from the json
            const loadedBook : BookModel = {
                    id: responseJson.id,
                    title: responseJson.title,
                    author: responseJson.author,
                    description:responseJson.description,
                    copies:responseJson.copies,
                    copiesAvailable:responseJson.copiesAvailable,
                    category:responseJson.category,
                    img:responseJson.img
            };

            setBook(loadedBook);
            setIsLoading(false);
        };
        //in case any error happens we set isLoading to false & setHttpError to the error that comes in
        fetchBook().catch((error: any) => {
            setIsLoading(false);
            setHttpError(error.message);
        })
    }, [isCheckedOut]);

    //useEffect is called the first time at the creation of the component & it gets called every time something in the last array changes
     useEffect(() => {
         const fetchUserCurrentLoansCount = async () => {
            if (authState && authState.isAuthenticated) {
                const url = `https://localhost:8443/api/books/secure/currentloans/count`;
                const requestOptions = {
                    method: 'GET',
                    headers: { 
                        Authorization: `Bearer ${authState.accessToken?.accessToken}`,
                        'Content-Type': 'application/json'
                     }
                };
                const currentLoansCountResponse = await fetch(url, requestOptions);
                if (!currentLoansCountResponse.ok)  {
                    throw new Error('Something went wrong! with fetchUserCurrentLoansCount');
                }
                const currentLoansCountResponseJson = await currentLoansCountResponse.json();
                setcurrentLoansCount(currentLoansCountResponseJson);
            }
            setIsLoadingCurrentLoansCount(false); 
         }
         fetchUserCurrentLoansCount().catch((error: any) => {
             setIsLoadingCurrentLoansCount(false);
             setHttpError(error.message);
         })
     }, [authState, isCheckedOut]);

     useEffect(() => {
        const fetchUserCheckedOutBook = async() => {
            if (authState && authState.isAuthenticated) {
                const url = `https://localhost:8443/api/books/secure/ischeckedout/byuser?bookId=${bookId}`;
                const requestOptions = {
                    method: 'GET',
                    headers: { 
                        Authorization: `Bearer ${authState.accessToken?.accessToken}`,
                        'Content-Type': 'application/json'
                     }
                };
                const bookCheckedOut = await fetch(url, requestOptions);

                if (!bookCheckedOut.ok)  {
                    throw new Error('Something went wrong with fetchUserCheckedOutBook!');
                }

                const bookCheckedOutResponseJson = await bookCheckedOut.json();
                setIsCheckedOut(bookCheckedOutResponseJson);
            }
            setIsLoadingBookCheckedOut(false);
        }
        fetchUserCheckedOutBook().catch((error : any) =>{
            setIsLoadingBookCheckedOut(false);
            setHttpError(error.message);
        })
     },[authState])

    if(isLoadingBook || isLoadingCurrentLoansCount || isLoadingBookCheckedOut) {
        return (
        <div className="container m-5">
                <SpinnerLoading/>
        </div>)
    }

    if(httpError) {
        return (
        <div className="container m-5">
                <p>{httpError}</p>
        </div>)
    }

    //function to update database when a user checks out a book
    async function checkoutBook() {
        const url = `https://localhost:8443/api/books/secure/checkout?bookId=${book?.id}`;

        const requestOptions = {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${authState?.accessToken?.accessToken}`,
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin':'*',
                'Access-Control-Allow-Methods':'POST,PATCH,OPTIONS,PUT'
            }
        };

        const checkoutResponse = await fetch(url, requestOptions);
        if (!checkoutResponse.ok) {
            throw new Error('Something went wrong!');
        }
        setIsCheckedOut(true);
    }
    
    return (
        <div>
            <div className="container d-none d-lg-block">
                <div className="row mt-5">
                    <div className="col-sm-2 col-md-2">
                       {book?.img?
                        <img src={book?.img} width='226' height='349' alt="Book" />
                        :
                        <img src={require('/Users/siratgill/VS-workspace/libraryApp/03-frontend/react-library/src/Images/BooksImages/book-luv2code-1000.png')} width='226' height='349' alt="book" />
                        }
                    </div>
                    <div className="col-4 col-md-4 container">
                        <div className="ml-2 ">
                            <h2>{book?.title}</h2>
                            <h5 className="tect-primary">{book?.author}</h5>
                            <p className="lead">{book?.description}</p>
                        </div>
                    </div>
                    <Checkout book={book} mobile={false} currentLoansCount={currentLoansCount} isAuthenticated={authState?.isAuthenticated} isCheckedOut={isCheckedOut} checkoutBook={checkoutBook}/>
                </div>
                <hr/>
            </div>
        </div>
    );
}