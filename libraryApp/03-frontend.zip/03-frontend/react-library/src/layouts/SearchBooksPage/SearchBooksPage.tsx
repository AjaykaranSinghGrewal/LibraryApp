import { useEffect,useState } from "react";
import BookModel from "../../models/BookModel";
import { SpinnerLoading } from "../Utils/SpinnerLoading";
import { SearchBook } from "./components/SearchBook";
import { Pagination } from "../Utils/Pagination";

export const SearchBooksPage = () => {
    //books that are going to be loading on the page
    const [books, setBooks] = useState<BookModel[]>([]);

    //display the loading sign until api returns with data
    const[isLoading, setIsLoading] = useState(true);

    //error state in case api fails. initially its set to null
    const [httpError, setHttpError] = useState(null);

    //set states for pagination
    const[currentPage, setCurrentPage] = useState(1);
    const[booksPerPage] = useState(5);
    const[totalAmountofBooks, setTotalAmountofBooks] = useState(0);
    const[totalPages, setTotalPages] = useState(0);

    //set states for findByTitle front-end
    const[search,setSearch] = useState('');
    const[searchUrl, setSearchUrl] = useState('');


    //useEffect is called the first time at the creation of the component & it gets called every time something in the last array changes
    //we used currentPage in the final array of useEffect. this means that each time currentpage change reload the useEffect
    useEffect(() => {
        const fetchBooks = async () => {
            const baseUrl: string = `https://localhost:8443/api/books`;

            //set page size as currentPage-1 as pages start from 0 & number of books displayed per page will be a constant that we set earlier as 5
            let url:string = '';

            //if searchUrl is empty then get all books otherwise get books with search name in it
            if(searchUrl === '') {
                url = `${baseUrl}?page=${currentPage-1}&size=${booksPerPage}`;
            } else {
                url = baseUrl + searchUrl;
            }

            //we need to use await becaus its an asynchronous function
            const response = await fetch(url);

            if(!response.ok) {
                throw new Error('Something went wrong');
            }

            const responseJson = await response.json();
            //to get to books array object in json response 
            const responseData = responseJson._embedded.books;

            //set totalAmountofBooks & totalPages variable from json response
            setTotalAmountofBooks(responseJson.page.totalElements);
            setTotalPages(responseJson.page.totalPages);

            //create a variable of BookModel array & keep it empty
            const loadedBooks : BookModel[] = [];

            //for each book in json response add book to array
            for (const key in responseData) {
                loadedBooks.push({
                    id: responseData[key].id,
                    title: responseData[key].title,
                    author: responseData[key].author,
                    description:responseData[key].description,
                    copies:responseData[key].copies,
                    copiesAvailable:responseData[key].copiesAvailable,
                    category:responseData[key].category,
                    img:responseData[key].img
                });
            }

            setBooks(loadedBooks);
            setIsLoading(false);
        };
        //in case any error happens we set isLoading to false & setHttpError to the error that comes in
        fetchBooks().catch((error: any) => {
            setIsLoading(false);
            setHttpError(error.message);
        })
        //each time useEffect is used we're going to scroll to the top of the page
        window.scrollTo(0,0);
    }, 
    //this array means that each time currentpage or SearchUrl changes then reload the useEffect & re-render the page
    [currentPage,searchUrl]);

    if(isLoading) {
        return (
        <div className="container m-5">
                <SpinnerLoading/>
        </div>)
    }

    if(httpError) {
        return (
        <div className="container m-5">
                <p>{httpError}</p>
        </div>)
    }

    const searchHandleChange = () => {
        if(search === '') {
            setSearchUrl('');
        } else {
            setSearchUrl(`/search/findByTitleContaining?title=${search}&page=0&size=${booksPerPage}`)
        }
    }

    const indexOfLastBook : number = currentPage * booksPerPage;
    const indexOfFirstBook : number = indexOfLastBook - booksPerPage;
    let lastItem = booksPerPage * currentPage < totalAmountofBooks ? booksPerPage * currentPage : totalAmountofBooks;

    const paginate = (pageNumber : number) => setCurrentPage(pageNumber);

    return (
        <div>
            <div className="container">
                <div>
                    <div className="row mt-5">
                        <div className="col-6">
                            <div className="d-flex">
                                <input type="search" className="form-control me-2" placeholder="Search" aria-labelledby="Search" onChange={e => setSearch(e.target.value)}/>
                                <button className="btn btn-outline-success" onClick={() => searchHandleChange()}>Search</button>
                            </div>
                        </div>
                    </div>

                    <div className="marin-top-3">
                        <h5>Number of Results: ({totalAmountofBooks})</h5>
                    </div>
                    <p>
                        {indexOfFirstBook+1} to {lastItem} of {totalAmountofBooks} items:
                    </p>
                    {books.map(book => (
                        <SearchBook book={book} key={book.id} />
                    ))}

                    {
                        //if total pages > 1 then render the pagination page
                        totalPages > 1 && <Pagination currentPage={currentPage} totalPages={totalPages} paginate={paginate} />
                    }
                </div>
            </div>
        </div>
    );
}